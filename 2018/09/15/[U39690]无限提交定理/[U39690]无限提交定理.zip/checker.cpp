#include "testlib.h"
int main(int argc,char* argv[]) {
	registerTestlibCmd(argc, argv);
	int get=ouf.readInt();
	int jans=ans.readInt();
	if(get==jans) {
		quitf(_ok,"Well done!You`ve got cqxxx`s attention.");
	} else {
		quitf(TResult(abs((float)get-jans)/(float)10007),"Oooops!Try again.");
	}
	return 0;
}
